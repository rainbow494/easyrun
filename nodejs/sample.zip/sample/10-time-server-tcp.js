var net = require('net');
var moment = require('moment');
var server = net.createServer(function (c) {
    // console.log('client connected');
    // c.on('end', function() {
    //     console.log('client disconnected');
    // });
    // c.write('hello\r\n');
    // c.pipe(c);


    // c.write(moment(new Date()).format('YYYY-MM-DD HH:mm'));
    c.end(moment(new Date()).format('YYYY-MM-DD HH:mm'));
});

server.listen(process.argv[2], function () {
    //console.log('listen')
});
