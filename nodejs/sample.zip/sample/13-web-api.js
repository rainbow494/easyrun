var http = require('http');
var url = require('url');
var moment = require('moment');


var test = new Date();

var server = http.createServer(function (req,res) {

    //console.log(url.parse(req.url, true));

    var pathname = url.parse(req.url, true).pathname;
    var time = url.parse(req.url, true).query.iso;

    res.writeHead(200,{'Content-Type':'application/json'});

    switch (pathname) {
        case '/api/parsetime':
        res.write(JSON.stringify({
            "hour":  moment(time).hour(),
            "minute":  moment(time).minute(),
            "second":  moment(time).second()
         }));
            break;
        case '/api/unixtime':
        var xtime = moment.utc(time).format('x').toString();
        //console.log(xtime.toString());
        res.write(JSON.stringify({
            "unixtime": xtime.toString()
        }));
            break;
        default:

    }

    res.end();
})

server.listen(process.argv[2]);
