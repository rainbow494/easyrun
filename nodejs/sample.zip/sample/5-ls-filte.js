var fs = require('fs');
module.exports = function(dir, filte, callback){
    fs.readdir(dir, function (err, list) {
        if (err){
            return callback(err);
        }

        var result = [];
        for (var i = 0; i < list.length; i++) {
            if (list[i].split('.')[1] == filte){
                result.push(list[i]);
            }
        }

        return callback(null, result);
    });
}
