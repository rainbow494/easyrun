var http = require('http');
var map = require('through2-map');

var server = http.createServer(function(req, res){
    if (req.method == 'POST') {
        //console.log(req);
        var map = require('through2-map')
        req.pipe(map(function (chunk) {
             return chunk.toString().toUpperCase()
        })).pipe(res);
    }
});

var port = process.argv[2];
server.listen(Number(port));
